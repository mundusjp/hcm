<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Goalmatching extends Model
{
    //
}
