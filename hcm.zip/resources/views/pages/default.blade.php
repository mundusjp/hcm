@extends('layouts.default')

@section('content')
<!-- coding starts here  -->
<?php phpinfo() ?>

<!-- coding endss here  -->
@stop
