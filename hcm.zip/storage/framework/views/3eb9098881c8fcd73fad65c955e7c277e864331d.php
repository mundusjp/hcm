<?php /* C:\xampp\htdocs\hcm\resources\views/layouts/ubah.blade.php */ ?>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <?php echo $__env->make('parts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
  <?php echo $__env->make('parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="slim-navbar">
    <div class="container">
      <ul class="nav">
        <li class="nav-item">
          <form id="back" action="<?php echo e(route('back')); ?>" method="get">
            <?php echo csrf_field(); ?>
          <a href="javascript:;" onclick="document.getElementById('back').submit();" class="nav-link">
            <i class="icon ion-home"></i>
            <span>Home</span>
          </a>
          </form>
        </li>
      </ul>
    </div><!-- container -->
  </div><!-- slim-navbar -->

  <?php echo $__env->yieldContent('content'); ?>
  <?php echo $__env->make('parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('parts.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
