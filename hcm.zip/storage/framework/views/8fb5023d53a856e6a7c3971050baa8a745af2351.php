<?php /* C:\xampp\htdocs\hcm\resources\views/pages/dashboard.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- coding starts here  -->
<div class="slim-mainpanel">
     <div class="container">
       <div class="slim-pageheader">
         <ol class="breadcrumb slim-breadcrumb">
           <li class="breadcrumb-item"><a href="#">Home</a></li>
           <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
         </ol>
         <h6 class="slim-pagetitle">Dashboard</h6>
       </div><!-- slim-pageheader -->
       <div class="section-wrapper mg-t-20">
         <?php if(session('success')): ?>
         <div class="alert alert-success" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong> <?php echo e(session('success')); ?> </strong>
         </div><!-- alert -->
         <?php elseif(session('failed')): ?>
         <div class="alert alert-danger" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong> <?php echo e(session('failed')); ?> </strong>
         </div><!-- alert -->
         <?php endif; ?>
         <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
         <!--                                UNTUK KELAS Superadmin                                    -->
         <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
         <?php if(Auth::user()->kelas_jabatan == 1): ?>
         <label class="section-title">Superadmin</label>
         <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
         <!--                                UNTUK KELAS DIREKSI                                       -->
         <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
         <?php elseif(Auth::user()->kelas_jabatan <= 5 && Auth::user()->kelas_jabatan != "TNO"): ?>
         <label class="section-title">Status Program Kerja Anda</label>
         <?php $__currentLoopData = $officer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="section-title tx-warning"><?php echo e($vp->sub_divisi); ?> - <?php echo e($vp->nama); ?></label>
           <div class="table-responsive">
             <table class="table table-hover mg-b-0">
               <thead>
                 <tr>
                   <th style="width:5%;">No.</th>
                   <th style="width:50%;">Program Kerja</th>
                   <th style="text-align:center;width:15%;">Status</th>
                   <th style="text-align:center;width:15%;">Progres</th>
                   <th style="text-align:center;width:5%;">Target</th>
                   <th style="text-align:center;width:10%;">Aksi</th>
                 </tr>
               </thead>
               <tbody>
                 <?php $i=0; ?>
                 <?php $__currentLoopData = $direksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($programs->nipp_pj == $vp->nipp): ?>
                 <?php $i++; ?>
                 <tr>
                   <td><?php echo e($i); ?></td>
                   <td><?php echo e($programs->program_kerja); ?></td>
                   <?php if($programs->status_proker == "Belum Direspon" || $programs->status_proker == "Belum Disampaikan"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-dark"><?php echo e($programs->status_proker); ?></span></td>
                   <?php elseif($programs->status_proker == "Sedang Diproses"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-info"><?php echo e($programs->status_proker); ?></span></td>
                   <?php elseif($programs->status_proker == "Terlambat" || $programs->status_proker == "Diperingatkan" || $programs->status_proker == "Ditunda" || $programs->status_proker == "Konfirmasi Dibatalkan"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-warning"><?php echo e($programs->status_proker); ?></span></td>
                   <?php elseif($programs->status_proker == "Dibatalkan"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-danger"><?php echo e($programs->status_proker); ?></span></td>
                   <?php else: ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-success"><?php echo e($programs->status_proker); ?></span></td>
                   <?php endif; ?>
                   <td>
                     <div class="progress mg-b-5">
                       <div class="progress-bar progress-bar-lg bg-warning wd-<?php echo e($programs->progres); ?>p" role="progressbar" aria-valuenow="<?php echo e($programs->progres); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e($programs->progres); ?>%</div>
                     </div>
                   </td>
                   <td style="text-align:center;"><?php echo e($programs->target_bulanan); ?>%</td>
                   <form action="<?php echo e(route('direksi.edit-target',$programs->id)); ?>" method="get">
                     <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-warning">Ubah Target</button></td>
                  </form>
                 </tr>
                 <?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
             </table>
           </div>
           <hr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
             <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
             <!--                               UNTUK KELAS VICE PRESIDENT                                 -->
             <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
             <?php elseif(Auth::user()->kelas_jabatan > 5 && Auth::user()->kelas_jabatan <=8): ?>
             <label class="section-title">Dashboard Vice President of <?php echo e(Auth::user()->sub_divisi); ?></label>
             <hr>
             <button class="btn btn-outline-warning float-right" data-toggle="modal" data-target="#assigntasktodvp"> Tambahkan</button>
             <label class="section-title">Assign Task to Deputy Vice President</label>
             <p>Berikut adalah tabel dengan pembagian pekerjaan ke DVP anda</p>
             <table class="table table-orange">
               <thead>
               <tr>
                 <td style="width:25px;">ID</td>
                 <td style="width:300px;text-align:center;">Task</td>
                 <td style="width:50px;text-align:center;">Penanggung Jawab</td>
                 <td style="width:25px;text-align:center;">Status</td>
                 <td style="width:200px;text-align:center;">Keterangan</td>
                 <td style="width:100px;text-align:center">Bukti</td>
                 <td style="width:25px;text-align:center;">Konfirmasi</td>
                 <td style="width:25px;text-align:center;">Tolak</td>
                 <td style="width:25px;text-align:center;">Batalkan</td>
               </tr>
               </thead>
               <tbody>
                 <?php $i=0;?>
                 <?php $__currentLoopData = $assigned_proker_vp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php $i++;?>
                 <tr>
                   <td><?php echo e($i); ?></td>
                   <td><?php echo e($program->program_kerja); ?></td>
                   <td><?php $user= App\User::where('nipp',$program->nipp_pj)->first(); echo $user->nama;?></td>
                   <?php if($program->status_proker == "Belum Direspon"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-dark"><?php echo e($program->status_proker); ?></span></td>
                   <?php elseif($program->status_proker == "Sedang Diproses"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-info"><?php echo e($program->status_proker); ?></span></td>
                   <?php elseif($program->status_proker == "Terlambat" || $program->status_proker == "Diperingatkan" || $program->status_proker == "Ditunda" || $program->status_proker == "Konfirmasi Dibatalkan"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-warning"><?php echo e($program->status_proker); ?></span></td>
                   <?php elseif($program->status_proker == "Dibatalkan"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-danger"><?php echo e($program->status_proker); ?></span></td>
                   <?php else: ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-success"><?php echo e($program->status_proker); ?></span></td>
                   <?php endif; ?>
                   <td><?php echo e($program->keterangan); ?></td>
                   <?php if(!empty($program->bukti_penyelesaian)): ?>
                   <td><a href="<?php echo e($program->bukti_penyelesaian); ?>" target="_blank">File</a></td>
                   <?php elseif($program->status_proker == "Selesai"): ?>
                   <td>Tanpa Bukti</td>
                   <?php else: ?>
                   <td>Belum Ada</td>
                   <?php endif; ?>
                   <?php if($program->status_proker == "Belum Direspon" || $program->status_proker == "Sedang Diproses" || $program->status_proker == "Diperingatkan"): ?>
                   <td><button disabled class="btn btn-outline-success">Konfirmasi</button></td>
                   <td><button disabled class="btn btn-outline-warning">Tolak</button></td>
                   <form method="get" action="<?php echo e(route('vice-president.batalkan-page',$program->id)); ?>">
                     <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-danger">Batalkan</button></td>
                  </form>
                   <?php elseif($program->status_proker == "Terlambat" || $program->status_proker == "Ditunda" || $program->status_proker == "Konfirmasi Dibatalkan"): ?>
                   <td><button disabled class="btn btn-outline-success">Konfirmasi</button></td>
                   <form method="get" action="<?php echo e(route('vice-president.peringatkan-page',$program->id)); ?>">
                     <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-warning">Peringatkan</button></td>
                  </form>
                   <form method="get" action="<?php echo e(route('vice-president.batalkan-page',$program->id)); ?>">
                     <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-danger">Batalkan</button></td>
                  </form>
                   <?php elseif($program->status_proker == "Konfirmasi Selesai"): ?>
                   <form method="post" action="<?php echo e(route('vice-president.konfirmasi',$program->id)); ?>">
                     <?php echo method_field('PATCH'); ?>
                     <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-success">Konfirmasi</button></td>
                  </form>
                  <form method="get" action="<?php echo e(route('vice-president.reject-page',$program->id)); ?>">
                    <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-warning">Tolak</button></td>
                  </form>
                   <td><button disabled class="btn btn-outline-danger">Batalkan</button></td>
                   <?php elseif($program->status_proker == "Selesai" || $program->status_proker == "Dibatalkan"): ?>
                   <td><button disabled class="btn btn-outline-success">Konfirmasi</button></td>
                   <td><button disabled class="btn btn-outline-warning">Tolak</button></td>
                   <td><button disabled class="btn btn-outline-danger">Batalkan</button></td>
                   <?php endif; ?>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
             </table>
             <?php echo e($assigned_proker_vp->links()); ?>

             <hr>
             <!-- ///////////////////////////////////////STATUS DVP////////////////////////////////////////////////  -->
             <label class="section-title">Status Deputy Vice Director</label>
             <p>Berikut adalah status dan performa dari seluruh DVP anda</p>
             <div class="row">
               <?php $__currentLoopData = $officer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="col">
                 <h6 class="tx-orange"><strong><?php echo e($user->nama); ?></strong></h6>
                 <?php $__currentLoopData = $performa_dvp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $performa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($performa->nipp == $user->nipp): ?>
                 <ul class="list-group">
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;"><?php echo e($performa->jumlah_task_minggu_ini); ?></span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Gagal Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;"><?php echo e($performa->jumlah_task_gagal_minggu_ini); ?></span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Minggu ini:</strong><br> <span class="text-muted align-right"><?php echo e($performa->performa_minggu_ini); ?>%</span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Bulan ini:</strong><br> <span class="text-muted align-right"><?php echo e($performa->performa_bulan_ini); ?>%</span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Lihat Logbook:</strong><br>
                      <span class="text-muted"><a href="<?php echo e(route('logbook-harian-coachee',$user->id)); ?>">Harian</a></span>
                      <span class="text-muted"> | <a href="<?php echo e(route('logbook-mingguan-coachee',$user->id)); ?>">Mingguan</a></span>
                      <span class="text-muted"> | <a href="<?php echo e(route('logbook-bulanan-coachee',$user->id)); ?>">Bulanan</a></span></p>
                  </li>
                </ul>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
             <!-- ///////////////////////////////////////MODALS////////////////////////////////////////////////  -->
             <!-- ################## MODAL 1 ###################### -->
             <div class="modal fade" id="assigntasktodvp" tabindex="-1" role="dialog" aria-labelledby="assigntask" aria-hidden="true">
               <div class="modal-dialog modal-lg">
                 <div class="modal-content">
                   <div class="modal-header">
                     <h6 class="modal-title" id="ConfigUpdateLabel">Berikan Tugas ke DVP</h6>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                       <span aria-hidden="true">&times;</span>
                     </button>
                   </div>
                   <div class="modal-body">
                     <div class="form-layout">
                       <div class="row mg-b-25">
                         <div class="col-12">
                           <div class="form-group">
                             <form method="post" action="<?php echo e(route('assign-task-to-dvp')); ?>">
                              <?php echo csrf_field(); ?>
                             <label class="form-control-label">Program Kerja Anda <span class="tx-danger">*</span></label>
                             <select name="id" class="form-control select2" data-placeholder="Choose one">
                               <optgroup label="Program Mingguan">
                                 <?php $__currentLoopData = $proker_vp_mingguan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($program->id); ?>"><?php echo e($program->program_kerja); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </optgroup>
                               <optgroup label="Program Bulanan">
                                 <?php $__currentLoopData = $proker_vp_bulanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($program->id); ?>"><?php echo e($program->program_kerja); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </optgroup>
                               <optgroup label="Program Tahunan">
                                 <?php $__currentLoopData = $proker_vp_tahunan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($program->id); ?>"><?php echo e($program->program_kerja); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </optgroup>
                               <optgroup label="Program 1/2 Tahunan">
                                 <?php $__currentLoopData = $proker_vp_settahunan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($program->id); ?>"><?php echo e($program->program_kerja); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               </optgroup>


                             </select>
                           </div>
                         </div>
                         <div class="col-12">
                           <div class="form-group">
                             <label class="form-control-label">Target: <span class="tx-danger">*</span></label>
                             <textarea class="form-control" type="text" name="target"></textarea>
                           </div>
                         </div>
                         <div class="col-12">
                           <div class="form-group">
                             <label class="form-control-label">DVP Anda <span class="tx-danger">*</span></label>
                             <select name="nipp_pj" class="form-control select2" data-placeholder="Choose one">
                               <?php $__currentLoopData = $officer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($user->nipp); ?>"><?php echo e($user->nama); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                           </div>
                         </div>
                       </div>
                     </div>
                   </div>
                   <div class="modal-footer" style="text-align:right;">
                     <button type="submit" class="btn btn-primary bd-0">Tambahkan</button>
                     <button type="button" class="btn btn-secondary" class="close" data-dismiss="modal">Cancel</button>
                      </form>
                     <!-- <button type="submit" class="btn btn-primary">Update</button> -->
                   </div>
                 </div>
               </div><!-- modal-dialog -->
             </div><!-- modal -->
             <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
             <!--                            UNTUK KELAS DEPUTY VICE PRESIDENT                             -->
             <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
             <?php elseif(Auth::user()->kelas_jabatan > 8 && Auth::user()->kelas_jabatan <=10): ?>
             <label class="section-title">Dashboard Deputy Vice President of <?php echo e(Auth::user()->sub_subdivisi); ?></label>
             <hr>
             <button class="btn btn-warning float-right" data-toggle="modal" data-target="#tambahlogbook"> Tambah Logbook</button>
             <button class="btn btn-outline-warning float-right" data-toggle="modal" data-target="#assigntasktoofficer"> Assign Task </button>
             <label class="section-title">Task List dari Vice President of <?php echo e(Auth::user()->sub_divisi); ?></label>
             <table class="table table-orange">
               <thead>
               <tr>
                 <td style="width:25px;">ID</td>
                 <td style="width:300px;text-align:center;">Task</td>
                 <td style="width:200px;text-align:center;">Target</td>
                 <td style="width:25px;text-align:center;">Status</td>
                 <td style="width:40px;text-align:center;">Deadline</td>
                 <td style="width:200px;text-align:center;">Keterangan</td>
                 <td style="width:100px;text-align:center">Bukti</td>
                 <td style="width:15px;text-align:center;">Proses</td>
                 <td style="width:15px;text-align:center;">Tunda</td>
                 <td style="width:15px;text-align:center;">Selesai</td>
               </tr>
               </thead>
               <tbody>
                 <?php $i=0;?>
                 <?php $__currentLoopData = $proker_dari_vp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php $i++;
                 $now = Carbon\Carbon::now()->setTimezone('Asia/Jakarta');
                 $date = Carbon\Carbon::parse($program->due_date);
                 $due_date = $date->diffInDays($now);
                 ?>
                 <tr>
                   <td><?php echo e($i); ?></td>
                   <td><?php echo e($program->program_kerja); ?></td>
                   <td><?php echo e($program->target); ?></td>
                   <?php if($program->status_proker == "Belum Direspon" || $program->status_proker == "Ditolak"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-dark"><?php echo e($program->status_proker); ?></span></td>
                   <?php elseif($program->status_proker == "Sedang Diproses"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-info"><?php echo e($program->status_proker); ?></span></td>
                   <?php elseif($program->status_proker == "Terlambat" || $program->status_proker == "Diperingatkan" || $program->status_proker == "Ditunda" || $program->status_proker == "Konfirmasi Dibatalkan"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-warning"><?php echo e($program->status_proker); ?></span></td>
                   <?php elseif($program->status_proker == "Dibatalkan"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-danger"><?php echo e($program->status_proker); ?></span></td>
                   <?php else: ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-success"><?php echo e($program->status_proker); ?></span></td>
                   <?php endif; ?>
                   <?php if($program->status_proker == "Selesai"): ?>
                   <td><strong class="tx-success">Selesai</strong></td>
                   <?php elseif($due_date > 3): ?>
                   <td><div class="tx-success"><strong><?php echo e($due_date); ?> Days</strong></div></td>
                   <?php elseif($due_date <=3 && $due_date >0): ?>
                   <td><div class="tx-danger"><strong><?php echo e($due_date); ?> Days</strong></div></td>
                   <?php else: ?>
                   <td><strong class="tx-danger">Terlambat</strong></td>
                   <?php endif; ?>
                   <td><?php echo e($program->keterangan); ?></td>
                   <?php if(!empty($program->bukti_penyelesaian)): ?>
                   <td><a href="<?php echo e($program->bukti_penyelesaian); ?>" target="_blank">File</a></td>
                   <?php elseif($program->status_proker == "Selesai"): ?>
                   <td>Tanpa Bukti</td>
                   <?php else: ?>
                   <td>Belum Ada</td>
                   <?php endif; ?>
                   <?php if($program->status_proker == "Belum Direspon" || $program->status_proker == "Diperingatkan" || $program->status_proker == "Ditolak"): ?>
                   <form method="post" action="<?php echo e(route('deputy-vice-president.proses',$program->id)); ?>">
                     <?php echo method_field('PATCH'); ?>
                     <?php echo csrf_field(); ?>
                   <td style="width:15px;text-align:center;"><button class="btn btn-outline-info">Proses</button></td>
                  </form>
                   <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-warning">Tunda</button></td>
                   <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-success">Selesai</button></td>
                   <?php elseif($program->status_proker == "Terlambat" || $program->status_proker == "Sedang Diproses" || $program->status_proker == "Ditunda" || $program->status_proker == "Konfirmasi Dibatalkan" ): ?>
                   <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-info">Proses</button></td>
                   <form method="get" action="<?php echo e(route('deputy-vice-president.tunda-page',$program->id)); ?>">
                     <?php echo csrf_field(); ?>
                   <td style="width:15px;text-align:center;"><button class="btn btn-outline-warning">Tunda</button></td>
                  </form>
                   <form method="get" action="<?php echo e(route('deputy-vice-president.selesai-page',$program->id)); ?>">
                     <?php echo csrf_field(); ?>
                   <td style="width:15px;text-align:center;"><button class="btn btn-outline-success">Selesai</button></td>
                  </form>
                   <?php elseif($program->status_proker == "Konfirmasi Selesai"): ?>
                   <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-info">Proses</button></td>
                   <form method="post" action="<?php echo e(route('deputy-vice-president.batal-selesai',$program->id)); ?>">
                     <?php echo csrf_field(); ?>
                     <?php echo method_field('PATCH'); ?>
                   <td style="width:15px;text-align:center;"><button class="btn btn-outline-warning">Batal Selesai</button></td>
                  </form>
                   <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-success">Selesai</button></td>
                   <?php elseif($program->status_proker == "Selesai" || $program->status_proker == "Dibatalkan"): ?>
                   <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-info">Proses</button></td>
                   <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-warning">Tunda</button></td>
                   <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-success">Selesai</button></td>
                   <?php endif; ?>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
             </table>

             <label class="section-title">Task List Team Anda</label>
             <table class="table table-orange">
               <thead>
               <tr>
                 <td style="width:25px;">ID</td>
                 <td style="width:300px;text-align:center;">Task</td>
                 <td style="width:50px;text-align:center;">Penanggung Jawab</td>
                 <td style="width:25px;text-align:center;">Status</td>
                 <td style="width:200px;text-align:center;">Keterangan</td>
                 <td style="width:25px;text-align:center;">Konfirmasi</td>
                 <td style="width:100px;text-align:center">Bukti</td>
                 <td style="width:25px;text-align:center;">Tolak</td>
                 <td style="width:25px;text-align:center;">Batalkan</td>
               </tr>
               </thead>
               <tbody>
                 <?php $i=0;?>
                 <?php $__currentLoopData = $proker_dvp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php $i++;?>
                 <tr>
                   <td><?php echo e($i); ?></td>
                   <td><?php echo e($program->program_kerja); ?></td>
                   <td><?php $user= App\User::where('nipp',$program->nipp_pj)->first(); if(!empty($user->nama)){echo $user->nama;}else{echo "Not Yet Assigned";};?></td>
                   <?php if($program->status_task == "Belum Disampaikan" || $program->status_task == "Belum Direspon"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-dark"><?php echo e($program->status_task); ?></span></td>
                   <?php elseif($program->status_task == "Sedang Diproses"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-info"><?php echo e($program->status_task); ?></span></td>
                   <?php elseif($program->status_task == "Terlambat" || $program->status_task == "Diperingatkan" || $program->status_task == "Ditunda" || $program->status_task == "Konfirmasi Dibatalkan"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-warning"><?php echo e($program->status_task); ?></span></td>
                   <?php elseif($program->status_task == "Dibatalkan"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-danger"><?php echo e($program->status_task); ?></span></td>
                   <?php else: ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-success"><?php echo e($program->status_task); ?></span></td>
                   <?php endif; ?>
                   <td><?php echo e($program->keterangan); ?></td>
                   <?php if(!empty($program->bukti_penyelesaian)): ?>
                   <td><a href="<?php echo e($program->bukti_penyelesaian); ?>" target="_blank">File</a></td>
                   <?php elseif($program->status_proker == "Selesai"): ?>
                   <td>Tanpa Bukti</td>
                   <?php else: ?>
                   <td>Belum Ada</td>
                   <?php endif; ?>
                   <?php if($program->status_task == "Belum Direspon" || $program->status_task == "Sedang Diproses" || $program->status_task == "Diperingatkan"): ?>
                   <td><button disabled class="btn btn-outline-success">Konfirmasi</button></td>
                   <td><button disabled class="btn btn-outline-warning">Tolak</button></td>
                   <form method="get" action="<?php echo e(route('deputy-vice-president.batalkan-page',$program->id)); ?>">
                     <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-danger">Batalkan</button></td>
                  </form>
                   <?php elseif($program->status_task == "Terlambat" || $program->status_task == "Ditunda" || $program->status_task == "Konfirmasi Dibatalkan"): ?>
                   <td><button disabled class="btn btn-outline-success">Konfirmasi</button></td>
                   <form method="get" action="<?php echo e(route('deputy-vice-president.peringatkan-page',$program->id)); ?>">
                     <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-warning">Peringatkan</button></td>
                  </form>
                   <form method="get" action="<?php echo e(route('deputy-vice-president.batalkan-page',$program->id)); ?>">
                     <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-danger">Batalkan</button></td>
                  </form>
                   <?php elseif($program->status_task == "Konfirmasi Selesai"): ?>
                   <form method="post" action="<?php echo e(route('deputy-vice-president.konfirmasi',$program->id)); ?>">
                     <?php echo method_field('PATCH'); ?>
                     <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-success">Konfirmasi</button></td>
                  </form>
                  <form method="get" action="<?php echo e(route('deputy-vice-president.reject-page',$program->id)); ?>">
                    <?php echo csrf_field(); ?>
                   <td><button class="btn btn-outline-warning">Tolak</button></td>
                  </form>
                   <td><button disabled class="btn btn-outline-danger">Batalkan</button></td>
                   <?php elseif($program->status_task == "Selesai" || $program->status_task == "Dibatalkan" || $program->status_task == "Belum Disampaikan"): ?>
                   <td><button disabled class="btn btn-outline-success">Konfirmasi</button></td>
                   <td><button disabled class="btn btn-outline-warning">Tolak</button></td>
                   <td><button disabled class="btn btn-outline-danger">Batalkan</button></td>
                   <?php endif; ?>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
             </table>
             <br><hr>
             <div class="row">
               <div class="col-6">
                 <label class="section-title">Logbook Harian</label>
                 <hr>
                 <table class="table table-orange">
                   <thead>
                     <tr>
                       <th>No.</th>
                       <th>Program Kerja Terkait</th>
                       <th>Target</th>
                       <th>Log Hari Ini</th>
                       <th>Status</th>
                     </tr>
                   </thead>
                   <tbody>
                     <?php $i=0;?>
                     <?php $__currentLoopData = $logbook_harian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php $i++;?>
                     <tr>
                       <td><?php echo e($i); ?></td>
                       <td><?php echo e($log->program_kerja_terkait); ?></td>
                       <td><?php echo e($log->target); ?></td>
                       <td><?php echo e($log->logbook); ?></td>
                       <?php if($log->status == "Selesai"): ?>
                       <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-success"><?php echo e($log->status); ?></span></td>
                       <?php elseif($log->status = "Ditunda"): ?>
                       <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-warning"><?php echo e($log->status); ?></span></td>
                       <?php else: ?>
                       <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-danger"><?php echo e($log->status); ?></span></td>
                       <?php endif; ?>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                 </table>
               </div>
               <div class="col-6">
                 <label class="section-title">Performa Anda</label>
                 <hr>
                 <?php if(!empty($performa_saya)): ?>
                 <ul class="list-group">
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;"><?php echo e($performa_saya->jumlah_task_minggu_ini); ?></span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Terlambat Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;"><?php echo e($performa_saya->jumlah_task_pending_minggu_ini); ?></span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Minggu ini:</strong><br> <span class="tx-success align-right"><?php echo e($performa_saya->performa_minggu_ini); ?></span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Bulan ini:</strong><br> <span class="text-success align-right"><?php echo e($performa_saya->performa_bulan_ini); ?></span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Lihat Logbook:</strong><br> <span class="text-muted"><a href="<?php echo e(url('logbook-harian')); ?>">Harian</a></span> <span class="text-muted">|
                      <a href="<?php echo e(url('logbook-mingguan')); ?>"> Mingguan </a></span>|
                      <a href="<?php echo e(url('logbook-bulanan')); ?>">Bulanan</a></p>
                  </li>
                </ul>
                <?php else: ?>
                <ul class="list-group">
                 <li class="list-group-item">
                   <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;">Belum ada Data!</span></p>
                 </li>
                 <li class="list-group-item">
                   <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Terlambat Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;">Belum ada Data!</span></p>
                 </li>
                 <li class="list-group-item">
                   <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Minggu ini:</strong><br> <span class="align-right">Belum ada Data!</span></p>
                 </li>
                 <li class="list-group-item">
                   <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Bulan ini:</strong><br> <span class="align-right">Belum ada Data!</span></p>
                 </li>
                 <li class="list-group-item">
                   <p class="mg-b-0"><strong class="tx-inverse tx-medium">Lihat Logbook:</strong><br> <span style="display:none;" class="text-muted"><a href="<?php echo e(url('logbook-harian')); ?>">Harian</a></span>
                     <span style="display:none;" class="text-muted"> | <a style="display:none;" href="<?php echo e(url('logbook-mingguan')); ?>"> Mingguan </a></span>
                     <span style="display:none;" class="text-muted"> | <a style="display:none;" href="<?php echo e(url('logbook-bulanan')); ?>">Bulanan</a></span></p>
                 </li>
               </ul>
                <?php endif; ?>
               </div>
               <div class="col-12">
                 <hr>
                 <label class="section-title">Performa Officer Anda</label>
                 <p>Berikut adalah status dan performa dari seluruh DVP anda</p>
                 <div class="row">
                   <?php $__currentLoopData = $officer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="col">
                     <h6 class="tx-orange"><strong><?php echo e($user->nama); ?></strong></h6>
                     <?php $__currentLoopData = $performa_dvp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $performa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($performa->nipp == $user->nipp): ?>
                     <ul class="list-group">
                      <li class="list-group-item">
                        <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;"><?php echo e($performa->jumlah_task_minggu_ini); ?></span></p>
                      </li>
                      <li class="list-group-item">
                        <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Gagal Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;"><?php echo e($performa->jumlah_task_gagal_minggu_ini); ?></span></p>
                      </li>
                      <li class="list-group-item">
                        <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Minggu ini:</strong><br> <span class="text-muted align-right"><?php echo e($performa->performa_minggu_ini); ?>%</span></p>
                      </li>
                      <li class="list-group-item">
                        <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Bulan ini:</strong><br> <span class="text-muted align-right"><?php echo e($performa->performa_bulan_ini); ?>%</span></p>
                      </li>
                      <li class="list-group-item">
                        <p class="mg-b-0"><strong class="tx-inverse tx-medium">Lihat Logbook:</strong><br>
                          <span class="text-muted"><a href="<?php echo e(route('logbook-harian-coachee',$user->id)); ?>">Harian</a></span>
                          <span class="text-muted"> | <a href="<?php echo e(route('logbook-mingguan-coachee',$user->id)); ?>">Mingguan</a></span>
                          <span class="text-muted"> | <a href="<?php echo e(route('logbook-bulanan-coachee',$user->id)); ?>">Bulanan</a></span></p>
                      </li>
                    </ul>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </div>
               </div>
             </div>
             <!-- ################## MODAL 1 ###################### -->
             <div class="modal fade" id="assigntasktoofficer" tabindex="-1" role="dialog" aria-labelledby="assigntask" aria-hidden="true">
               <div class="modal-dialog modal-lg">
                 <div class="modal-content">
                   <div class="modal-header">
                     <h6 class="modal-title" id="ConfigUpdateLabel">Berikan Tugas ke Officer</h6>
                     <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                       <span aria-hidden="true">&times;</span>
                     </button>
                   </div>
                   <div class="modal-body">
                     <div class="form-layout">
                       <div class="row mg-b-25">
                         <div class="col-12">
                           <div class="form-group">
                             <form method="post" action="<?php echo e(route('assign-task-to-officer')); ?>">
                              <?php echo csrf_field(); ?>
                             <label class="form-control-label">Program Kerja Anda <span class="tx-danger">*</span></label>
                             <select name="id" class="form-control select2" data-placeholder="Choose one">
                               <?php $__currentLoopData = $proker_dvp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($program->id); ?>"><?php echo e($program->program_kerja); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                           </div>
                         </div>
                         <div class="col-12">
                           <div class="form-group">
                             <label class="form-control-label">Target: <span class="tx-danger">*</span></label>
                             <textarea class="form-control" type="text" name="target"></textarea>
                           </div>
                         </div>
                         <div class="col-12">
                           <div class="form-group">
                             <label class="form-control-label">Officer Anda <span class="tx-danger">*</span></label>
                             <select name="nipp_pj" class="form-control select2" data-placeholder="Choose one">
                               <?php $__currentLoopData = $officer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($user->nipp); ?>"><?php echo e($user->nama); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </select>
                           </div>
                         </div>
                       </div>
                     </div>
                   </div>
                   <div class="modal-footer" style="text-align:right;">
                     <button type="submit" class="btn btn-primary bd-0">Tambahkan</button>
                     <button type="button" class="btn btn-secondary" class="close" data-dismiss="modal">Cancel</button>
                      </form>
                     <!-- <button type="submit" class="btn btn-primary">Update</button> -->
                   </div>
                 </div>
               </div><!-- modal-dialog -->
             </div><!-- modal -->
             <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
             <!--                               UNTUK KELAS OFFICER & TNO                                  -->
             <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
             <?php elseif(Auth::user()->kelas_jabatan >= 11 || Auth::user()->kelas_jabatan == "TNO"): ?>
             <label class="section-title">Log Harian</label>
             <button type="button"class="btn float-right" data-toggle="modal" data-target="#tambahlogbookofficer">Tambahkan </button>
             <p class="mg-b-20 mg-sm-b-40">Tuliskan Pekerjaan Anda Hari Ini</p>
             <table class="table table-orange">
               <thead>
                 <tr>
                   <th>No.</th>
                   <th>Program Kerja Terkait</th>
                   <th>Target</th>
                   <th>Log Hari Ini</th>
                   <th>Status</th>
                 </tr>
               </thead>
               <tbody>
                 <?php $i=0;?>
                 <?php $__currentLoopData = $logbook_harian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php $i++;?>
                 <tr>
                   <td><?php echo e($i); ?></td>
                   <td><?php echo e($log->program_kerja_terkait); ?></td>
                   <td><?php echo e($log->target); ?></td>
                   <td><?php echo e($log->logbook); ?></td>
                   <?php if($log->status == "Selesai"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-success"><?php echo e($log->status); ?></span></td>
                   <?php elseif($log->status = "Ditunda"): ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-warning"><?php echo e($log->status); ?></span></td>
                   <?php else: ?>
                   <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-danger"><?php echo e($log->status); ?></span></td>
                   <?php endif; ?>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
             </table>
             <br>
             <hr>
             <div class="row">
               <div class="col-12">
                 <?php if(!empty($exist_proker_dari_dvp)): ?>
                 <label class="section-title">List Tugas Anda</label>
                 <table class="table table-orange">
                   <thead>
                   <tr>
                     <td style="width:25px;">ID</td>
                     <td style="width:300px;text-align:center;">Program Kerja</td>
                     <td style="width:25px;text-align:center;">Status</td>
                     <td style="width:200px;text-align:center;">Keterangan</td>
                     <td style="width:25px;text-align:center;">Proses</td>
                     <td style="width:25px;text-align:center;">Tunda</td>
                     <td style="width:25px;text-align:center;">Selesai</td>
                   </tr>
                   </thead>
                   <tbody>
                     <?php $i=0;?>
                     <?php $__currentLoopData = $proker_dari_dvp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php $i++;?>
                     <tr>
                       <td><?php echo e($i); ?></td>
                       <td><?php echo e($program->program_kerja); ?></td>
                       <?php if($program->status_task == "Belum Disampaikan" || $program->status_task == "Belum Direspon"): ?>
                       <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-dark"><?php echo e($program->status_task); ?></span></td>
                       <?php elseif($program->status_task == "Sedang Diproses"): ?>
                       <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-info"><?php echo e($program->status_task); ?></span></td>
                       <?php elseif($program->status_task == "Terlambat" || $program->status_task == "Diperingatkan" || $program->status_task == "Ditunda" || $program->status_task == "Konfirmasi Dibatalkan"): ?>
                       <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-warning"><?php echo e($program->status_task); ?></span></td>
                       <?php elseif($program->status_task == "Dibatalkan"): ?>
                       <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-danger"><?php echo e($program->status_task); ?></span></td>
                       <?php else: ?>
                       <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-success"><?php echo e($program->status_task); ?></span></td>
                       <?php endif; ?>
                       <td><?php echo e($program->keterangan); ?></td>
                       <?php if($program->status_task == "Belum Direspon" || $program->status_task == "Diperingatkan" || $program->status_task == "Ditolak"): ?>
                       <form method="post" action="<?php echo e(route('officer.proses',$program->id)); ?>">
                         <?php echo method_field('PATCH'); ?>
                         <?php echo csrf_field(); ?>
                       <td style="width:15px;text-align:center;"><button class="btn btn-outline-info">Proses</button></td>
                      </form>
                       <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-warning">Tunda</button></td>
                       <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-success">Selesai</button></td>
                       <?php elseif($program->status_task == "Terlambat" || $program->status_task == "Sedang Diproses" || $program->status_task == "Ditunda" || $program->status_task == "Konfirmasi Dibatalkan" ): ?>
                       <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-info">Proses</button></td>
                       <form method="get" action="<?php echo e(route('officer.tunda-page',$program->id)); ?>">
                         <?php echo csrf_field(); ?>
                       <td style="width:15px;text-align:center;"><button class="btn btn-outline-warning">Tunda</button></td>
                      </form>
                       <form method="get" action="<?php echo e(route('officer.selesai-page',$program->id)); ?>">
                         <?php echo csrf_field(); ?>
                       <td style="width:15px;text-align:center;"><button class="btn btn-outline-success">Selesai</button></td>
                      </form>
                       <?php elseif($program->status_task == "Konfirmasi Selesai"): ?>
                       <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-info">Proses</button></td>
                       <form method="post" action="<?php echo e(route('officer.batal-selesai',$program->id)); ?>">
                         <?php echo csrf_field(); ?>
                         <?php echo method_field('PATCH'); ?>
                       <td style="width:15px;text-align:center;"><button class="btn btn-outline-warning">Batal Selesai</button></td>
                      </form>
                       <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-success">Selesai</button></td>
                       <?php elseif($program->status_task == "Selesai" || $program->status_task == "Dibatalkan"): ?>
                       <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-info">Proses</button></td>
                       <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-warning">Tunda</button></td>
                       <td style="width:15px;text-align:center;"><button disabled class="btn btn-outline-success">Selesai</button></td>
                       <?php endif; ?>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </tbody>
                 </table>
                 <?php else: ?>
                 <div class="alert alert-warning" role="alert">
                   <strong> Belum ada pekerjaan untuk hari ini! </strong>
                 </div><!-- alert -->
                 <?php endif; ?>
               </div>
               <div class="col-4">
                 <label class="section-title">Performa Anda</label>
                 <hr>
                 <?php if(!empty($performa_saya)): ?>
                 <ul class="list-group">
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;"><?php echo e($performa_saya->jumlah_task_minggu_ini); ?></span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Terlambat Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;"><?php echo e($performa_saya->jumlah_task_pending_minggu_ini); ?></span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Minggu ini:</strong><br> <span class="tx-success align-right"><?php echo e($performa_saya->performa_minggu_ini); ?></span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Bulan ini:</strong><br> <span class="text-success align-right"><?php echo e($performa_saya->performa_bulan_ini); ?></span></p>
                  </li>
                  <li class="list-group-item">
                    <p class="mg-b-0"><strong class="tx-inverse tx-medium">Lihat Logbook:</strong><br> <span class="text-muted"><a href="<?php echo e(url('logbook-harian')); ?>">Harian</a></span> <span class="text-muted">|
                      <a href="<?php echo e(url('logbook-mingguan')); ?>"> Mingguan </a></span>|
                      <a href="<?php echo e(url('logbook-bulanan')); ?>">Bulanan</a></p>
                  </li>
                </ul>
                <?php else: ?>
                <ul class="list-group">
                 <li class="list-group-item">
                   <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;">Belum ada Data!</span></p>
                 </li>
                 <li class="list-group-item">
                   <p class="mg-b-0"><strong class="tx-inverse tx-medium">Jumlah Pekerjaan Terlambat Minggu ini:</strong><br> <span class="text-muted" style="text-align:right;">Belum ada Data!</span></p>
                 </li>
                 <li class="list-group-item">
                   <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Minggu ini:</strong><br> <span class="align-right">Belum ada Data!</span></p>
                 </li>
                 <li class="list-group-item">
                   <p class="mg-b-0"><strong class="tx-inverse tx-medium">Performa Bulan ini:</strong><br> <span class="align-right">Belum ada Data!</span></p>
                 </li>
                 <li class="list-group-item">
                   <p class="mg-b-0"><strong class="tx-inverse tx-medium">Lihat Logbook:</strong><br> <span style="display:none;" class="text-muted"><a href="<?php echo e(url('logbook-harian')); ?>">Harian</a></span>
                     <span style="display:none;" class="text-muted"> | <a style="display:none;" href="<?php echo e(url('logbook-mingguan')); ?>"> Mingguan </a></span>
                     <span style="display:none;" class="text-muted"> | <a style="display:none;" href="<?php echo e(url('logbook-bulanan')); ?>">Bulanan</a></span></p>
                 </li>
               </ul>
                <?php endif; ?>
               </div>
             </div>
             <?php endif; ?>
             <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
             <!--                                         MODALS                                           -->
             <!-- ///////////////////////////////////////////////////////////////////////////////////////  -->
                   <div class="modal fade" id="tambahlogbook" tabindex="-1" role="dialog" aria-labelledby="ConfigUpdateLabel" aria-hidden="true">
                     <div class="modal-dialog modal-lg">
                       <div class="modal-content">
                         <div class="modal-header">
                           <h6 class="modal-title" id="ConfigUpdateLabel">Tambahkan Logbook Harian</h6>
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                             <span aria-hidden="true">&times;</span>
                           </button>
                         </div>
                         <div class="modal-body">
                           <div class="form-layout">
                             <div class="row mg-b-25">
                               <div class="col-6">
                                 <div class="form-group">
                                   <form method="post" action="<?php echo e(route('logbook.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                   <label class="form-control-label">Program Kerja Terkait <span class="tx-danger">*</span></label>
                                   <select name="id" class="form-control select2" data-placeholder="Choose one">
                                     <?php $__currentLoopData = $proker_dari_vp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($program->id); ?>"><?php echo e($program->program_kerja); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </select>
                                 </div>
                               </div>
                               <div class="col-6">
                                 <div class="form-group">
                                   <label class="form-control-label">Target: <span class="tx-danger">*</span></label>
                                   <input class="form-control" type="text" name="target">
                                 </div>
                               </div>
                               <div class="col-9">
                                 <div class="form-group">
                                   <label class="form-control-label">Log Hari ini: <span class="tx-danger">*</span></label>
                                   <textarea class="form-control" type="text" name="log"></textarea>
                                 </div>
                               </div>
                               <div class="col-3">
                                 <div class="form-group">
                                   <label class="form-control-label">Status <span class="tx-danger">*</span></label>
                                   <select name="status" class="form-control select2" data-placeholder="Choose one">
                                     <option>Selesai</option>
                                     <option>Tidak Selesai</option>
                                     <option>Ditunda</option>
                                     <option>Dibatalkan</option>
                                   </select>
                                 </div>
                               </div>
                             </div>
                           </div>
                         </div>
                         <div class="modal-footer" style="text-align:right;">
                           <?php if(empty($program)): ?>
                           <span class="tx-danger"><strong>Belum ada Task yang diamanahkan!</strong></span>
                           <button type="submit" class="btn btn-primary bd-0" disabled>Tambahkan</button><br>
                           <?php else: ?>
                           <button type="submit" class="btn btn-primary bd-0">Tambahkan</button>
                           <?php endif; ?>
                           <button type="button" class="btn btn-secondary" class="close" data-dismiss="modal">Cancel</button>
                            </form>
                           <!-- <button type="submit" class="btn btn-primary">Update</button> -->
                         </div>
                       </div>
                     </div><!-- modal-dialog -->
                   </div><!-- modal -->
                   <div class="modal fade" id="tambahlogbookofficer" tabindex="-1" role="dialog" aria-labelledby="ConfigUpdateLabel" aria-hidden="true">
                     <div class="modal-dialog modal-lg">
                       <div class="modal-content">
                         <div class="modal-header">
                           <h6 class="modal-title" id="ConfigUpdateLabel">Tambahkan Logbook Harian</h6>
                           <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                             <span aria-hidden="true">&times;</span>
                           </button>
                         </div>
                         <div class="modal-body">
                           <div class="form-layout">
                             <div class="row mg-b-25">
                               <div class="col-6">
                                 <div class="form-group">
                                   <form method="post" action="<?php echo e(route('logbook.store')); ?>">
                                    <?php echo csrf_field(); ?>
                                   <label class="form-control-label">Program Kerja Terkait <span class="tx-danger">*</span></label>
                                   <select name="id" class="form-control select2" data-placeholder="Choose one">
                                     <?php $__currentLoopData = $proker_dari_dvp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <option value="<?php echo e($program->id); ?>"><?php echo e($program->program_kerja); ?></option>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </select>
                                 </div>
                               </div>
                               <div class="col-6">
                                 <div class="form-group">
                                   <label class="form-control-label">Target: <span class="tx-danger">*</span></label>
                                   <input class="form-control" type="text" name="target">
                                 </div>
                               </div>
                               <div class="col-9">
                                 <div class="form-group">
                                   <label class="form-control-label">Log Hari ini: <span class="tx-danger">*</span></label>
                                   <textarea class="form-control" type="text" name="log"></textarea>
                                 </div>
                               </div>
                               <div class="col-3">
                                 <div class="form-group">
                                   <label class="form-control-label">Status <span class="tx-danger">*</span></label>
                                   <select name="status" class="form-control select2" data-placeholder="Choose one">
                                     <option>Selesai</option>
                                     <option>Tidak Selesai</option>
                                     <option>Ditunda</option>
                                     <option>Dibatalkan</option>
                                   </select>
                                 </div>
                               </div>
                             </div>
                           </div>
                         </div>
                         <div class="modal-footer" style="text-align:right;">
                           <?php if(empty($program)): ?>
                           <span class="tx-danger"><strong>Belum ada Task yang diamanahkan!</strong></span>
                           <button type="submit" class="btn btn-primary bd-0" disabled>Tambahkan</button><br>
                           <?php else: ?>
                           <button type="submit" class="btn btn-primary bd-0">Tambahkan</button>
                           <?php endif; ?>
                           <button type="button" class="btn btn-secondary" class="close" data-dismiss="modal">Cancel</button>
                            </form>
                           <!-- <button type="submit" class="btn btn-primary">Update</button> -->
                         </div>
                       </div>
                     </div><!-- modal-dialog -->
                   </div><!-- modal -->
           </div><!-- section-wrapper -->
     </div><!-- Container -->
</div><!--slim-mainpanel-->

<!-- coding endss here  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>