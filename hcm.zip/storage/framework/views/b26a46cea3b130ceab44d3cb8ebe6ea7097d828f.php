<?php /* C:\xampp\htdocs\hcm\resources\views/pages/goalmatching/coachee.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- coding starts here  -->
<div class="slim-mainpanel">
     <div class="container">
       <div class="slim-pageheader">
         <ol class="breadcrumb slim-breadcrumb">
           <li class="breadcrumb-item"><a href="#">Home</a></li>
           <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
         </ol>
         <h6 class="slim-pagetitle">Dashboard</h6>
       </div><!-- slim-pageheader -->
       <div class="section-wrapper mg-t-20">
         <?php if(session('success')): ?>
         <div class="alert alert-success" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong> <?php echo e(session('success')); ?> </strong>
         </div><!-- alert -->
         <?php elseif(session('failed')): ?>
         <div class="alert alert-danger" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong> <?php echo e(session('failed')); ?> </strong>
         </div><!-- alert -->
         <?php endif; ?>
         <div class="form-group mg-b-10-force">
           <label class="section-title">Pertanyaan 2 Mingguan</label>
           <p class="mg-b-20 mg-sm-b-40">Silahkan Isi Kuesioner di Bawah Ini</p>
               <table class="table table-orange">
                 <thead>
                 <tr>
                   <td>No</td>
                   <td>Pertanyaan</td>
                   <td style="text-align:center;">sudah</td>
                   <td style="text-align:center;">belum</td>
                 </tr>
                 </thead>
                 <tbody>
                   <?php $i=0; ?>
                   <form action="" method="post">
                  <?php $__currentLoopData = $pertanyaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tanya): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++; ?>
                 <tr>
                   <td><?php echo e($i); ?></td>
                   <td><?php echo e($tanya->pertanyaan); ?></td>
                   <td style="text-align:center;">
                       <input name="jawaban<?php echo e($i); ?>" id="sudah" type="checkbox">
                   </td>
                   <td style="text-align:center;">
                       <input name="jawaban<?php echo e($i); ?>" id="belum" type="checkbox">
                   </td>
                 </tr>
                </tbody>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </table>
               <div class="justifier" style="text-align:right;">
                 <button class="btn btn-warning" type="submit">Submit</button>
               </div>
              </form>
           </div><!-- section-wrapper -->
     </div><!-- Container -->
</div><!--slim-mainpanel-->

<!-- coding endss here  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>