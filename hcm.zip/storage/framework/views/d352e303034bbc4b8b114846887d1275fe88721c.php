<?php /* C:\xampp\htdocs\hcm\resources\views/parts/nav.blade.php */ ?>
<div class="slim-navbar">
  <div class="container">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="home">
          <i class="icon ion-home"></i>
          <span>Home</span>
        </a>
      </li>
      <li class="nav-item with-sub">
        <?php if(Auth::user()->kelas_jabatan <=5): ?>
        <a class="nav-link" href="direksi">
          <i class="icon fa fa-compass"></i>
          <span>Goalsetting</span>
        </a>
        <?php elseif(Auth::user()->kelas_jabatan >5 && Auth::user()->kelas_jabatan <= 8 ): ?>
        <a class="nav-link" href="vice-president">
          <i class="icon fa fa-compass"></i>
          <span>Goalsetting</span>
        </a>
        <?php elseif(Auth::user()->kelas_jabatan >8 && Auth::user()->kelas_jabatan <= 10 ): ?>
        <a class="nav-link" href="deputy-vice-president">
          <i class="icon fa fa-compass"></i>
          <span>Goalsetting</span>
        </a>
        <?php else: ?>
        <a class="nav-link" href="deputy-vice-president">
          <i class="icon fa fa-compass"></i>
          <span>Goalsetting</span>
        </a>
        <?php endif; ?>
        <div class="sub-item">
          <ul>
            <?php if(Auth::user()->kelas_jabatan <= 5 && Auth::user()->divisi == "Utama"): ?>
            <li><a href="perusahaan">Perusahaan</a></li>
            <li><a href="direksi">Direksi</a></li>
            <?php elseif(Auth::user()->kelas_jabatan <= 5 && Auth::user()->kelas_jabatan != "TNO"): ?>
            <li><a href="perusahaan">Perusahaan</a></li>
            <li><a href="direksi">Direksi</a></li>
            <li><a href="vice-president">Vice President</a></li>
            <?php else: ?>
            <li><a href="perusahaan">Perusahaan</a></li>
            <li><a href="direksi">Direksi</a></li>
            <li><a href="vice-president">Vice President</a></li>
            <li><a href="deputy-vice-president">DVP</a></li>
            <?php endif; ?>
          </ul>
        </div><!-- dropdown-menu -->
      </li>
      <!-- <?php if(Auth::user()->kelas_jabatan != 5 && Auth::user()->kelas_jabatan != 4): ?>
      <li class="nav-item with-sub">
        <a class="nav-link" href="goalmatching">
          <i class="icon fa fa-exchange"></i>
          <span>Goalmatching</span>
        </a>
        <div class="sub-item">
          <ul>
            <?php if(Auth::user()->kelas_jabatan >5 && Auth::user()->kelas_jabatan <= 8 ): ?>
            <li><a href="goalmatching-coach">Coach</a></li> -->
            <!-- <li><a href="goalmatching-evaluasi">Evaluasi</a></li> -->
            <!-- <?php elseif(Auth::user()->kelas_jabatan > 8 && Auth::user()->kelas_jabatan <=10): ?>
            <li><a href="goalmatching-coach">Coach</a></li>
            <li><a href="goalmatching-coachee">Coachee</a></li> -->
            <!-- <li><a href="goalmatching-evaluasi">Evaluasi</a></li> -->
            <!-- <?php else: ?>
            <li><a href="goalmatching-coachee">Coachee</a></li> -->
            <!-- <li><a href="goalmatching-evaluasi">Evaluasi</a></li> -->
            <!-- <?php endif; ?> -->
          <!-- </ul> -->
        <!--</div>--><!-- dropdown-menu -->
      <!-- <?php endif; ?> -->
    <!-- </li> -->
    </ul>
  </div><!-- container -->
</div><!-- slim-navbar -->
