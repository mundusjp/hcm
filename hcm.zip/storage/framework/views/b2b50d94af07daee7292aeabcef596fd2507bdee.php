<?php /* C:\xampp\htdocs\hcm\resources\views/pages/user/user.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- coding starts here  -->
<div class="slim-mainpanel">
     <div class="container">
       <div class="slim-pageheader">
         <ol class="breadcrumb slim-breadcrumb">
           <li class="breadcrumb-item"><a href="#">Home</a></li>
           <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
         </ol>
         <h6 class="slim-pagetitle">Dashboard</h6>
       </div><!-- slim-pageheader -->
       <div class="section-wrapper mg-t-20">
         <?php if(session('success')): ?>
         <div class="alert alert-success" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong> <?php echo e(session('success')); ?> </strong>
         </div><!-- alert -->
         <?php elseif(session('failed')): ?>
         <div class="alert alert-danger" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong> <?php echo e(session('failed')); ?> </strong>
         </div><!-- alert -->
         <?php endif; ?>
         <label class="section-title">User List</label>
         <p class="mg-b-20 mg-sm-b-40">Berikut adalah list user beserta tugas-tugasnya</p>
         <table class="table table-orange">
           <thead>
           <tr>
             <td>ID</td>
             <td>Nama</td>
             <td>Jabatan</td>
             <td>Divisi</td>
             <td>Actions</td>
           </tr>
           </thead>
           <tbody>
             <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
               <td><?php echo e($user->id); ?></td>
               <td><?php echo e($user->nama); ?></td>
               <td><?php echo e($user->jabatan); ?></td>
               <td><?php echo e($user->divisi); ?></td>
               <td><a href="<?php echo e(route('users.edit',$user->id)); ?>">Detail</a></td>
             </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </table>
         <?php echo e($users->links()); ?>

       </div>
     </div>
</div>
<!-- coding endss here  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>