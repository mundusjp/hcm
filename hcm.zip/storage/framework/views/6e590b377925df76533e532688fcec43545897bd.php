<?php /* C:\xampp\htdocs\hcm\resources\views/pages/default.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- coding starts here  -->
<?php phpinfo() ?>

<!-- coding endss here  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>