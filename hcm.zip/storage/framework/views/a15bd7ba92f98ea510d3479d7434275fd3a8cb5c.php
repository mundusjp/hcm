<?php /* C:\xampp\htdocs\hcm\resources\views/admin/home.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- coding starts here  -->
<div class="content">
  <!-- Animated -->
  <div class="animated fadeIn">
      <!-- Widgets  -->
      <div class="row">
        <div class="col-lg-6 col-md-6">
            <div class="card">
                <div class="card-body">
                  <a href="<?php echo e(route('superadmin.user')); ?>">
                    <div class="stat-widget-five">
                        <div class="stat-icon dib flat-color-4">
                            <i class="pe-7s-users"></i>
                        </div>
                        <div class="stat-content">
                            <div class="text-left dib">
                                <div class="stat-text"><span class="count"><?php echo e($users); ?></span></div>
                                <div class="stat-heading">Jumlah User</div>
                            </div>
                        </div>
                    </div>
                  </a>
                </div>
            </div>
        </div>

          <div class="col-lg-6 col-md-6">
              <div class="card">
                  <div class="card-body">
                      <div class="stat-widget-five">
                          <div class="stat-icon dib flat-color-1">
                              <i class="fa fa-book"></i>
                          </div>
                          <div class="stat-content">
                              <div class="text-left dib">
                                  <div class="stat-text"><span class="count"><?php echo e($yangbelum_count); ?></span> User</div>
                                  <div class="stat-heading">Belum isi log harian</div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                  <strong class="card-title">Belum mengisi Log Harian</strong>
                </div>
                <div class="card-body">
                  <table id="bootstrap-data-table" class="table table-striped table-bordered">
                      <thead>
                          <tr>
                              <th>No</th>
                              <th>Nama</th>
                              <th>Jabatan</th>
                              <th>Divisi</th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php $i=0; ?>
                        <?php $__currentLoopData = $yangbelum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemalas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++;
                        $user = App\User::where('nipp',$pemalas)->first();
                         ?>
                          <tr>
                              <td><?php echo e($i); ?></td>
                              <td><?php echo e($user->nama); ?></td>
                              <td><?php echo e($user->jabatan); ?></td>
                              <td><?php echo e($user->sub_divisi); ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
  <!-- /#add-category -->
  </div>
  <!-- .animated -->
  </div>
  <!-- /.content -->
<!-- coding endss here  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>