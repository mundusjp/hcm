<?php /* C:\xampp\htdocs\hcm\resources\views/parts/footer.blade.php */ ?>
<div class="slim-footer">
  <div class="container">
    <p>Copyright 2019 &copy; All Rights Reserved. PT Indonesia Kendaraan Terminal</p>
    <p>Designed by: <a href="">Human Capital Management Team</a></p>
  </div><!-- container -->
</div><!-- slim-footer -->
