<?php /* C:\xampp\htdocs\hcm\resources\views/pages/goalsetting/ubah/manajer.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Start Coding here -->
<div class="slim-mainpanel">
      <div class="container">
        <div class="slim-pageheader">
          <h6 class="slim-pagetitle">Ubah Program Kerja Vice President</h6>
        </div><!-- slim-pageheader -->
        <div class="section-wrapper">
          <form action="<?php echo e(route('vice-president.update',$program->id)); ?>" method="post">
          <?php echo method_field('PATCH'); ?>
          <?php echo e(csrf_field()); ?>

          <div class="form-layout">
            <div class="row mg-b-25">
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label">Nama: <span class="tx-danger">*</span></label>
                  <input class="form-control" type="text" name="nama" readonly value="<?php echo e(Auth::user()->nama); ?>" >
                </div>
              </div><!-- col-6 -->
              <div class="col-lg-3">
                <div class="form-group">
                  <label class="form-control-label">Sub-Divisi: <span class="tx-danger">*</span></label>
                  <input class="form-control" type="text" readonly name="divisi" value="<?php echo e($program->divisi); ?>">
                </div>
              </div><!-- col-3 -->
              <div class="col-lg-3">
                <div class="form-group">
                  <label class="form-control-label">NIPP: <span class="tx-danger">*</span></label>
                  <input class="form-control" type="text" readonly name="nipp" value="<?php echo e($program->nipp); ?>">
                </div>
              </div><!-- col-3 -->
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label">Program Direksi Terkait <span class="tx-danger">*</span></label>
                  <select name="program_direksi" class="form-control select2-show-search" data-placeholder="Choose one">
                    <option value="<?php echo e($program->id_prodir); ?>"><?php echo e($program->program_direksi); ?></option>
                    <?php $__currentLoopData = $direksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($program->id); ?>"><?php echo e($programs->program_kerja); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div><!-- col-6 -->
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label">Program Kerja Terkait <span class="tx-danger">*</span></label>
                  <select name="program_kerja_terkait" class="form-control select2-show-search" data-placeholder="Choose one">
                    <?php if(empty($program->program_kerja_terkait)): ?>
                    <option value="">Tidak Ada</option>
                    <?php else: ?>
                    <option value="<?php echo e($program->id_prokerkait); ?>"><?php echo e($program->program_kerja_terkait); ?></option>
                    <?php endif; ?>
                    <optgroup label="Program Tahunan">
                      <?php $__currentLoopData = $proker_tahunan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($program->id); ?>"><?php echo e($programs->program_kerja); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                    <optgroup label="Program 1/2 Tahunan">
                      <?php $__currentLoopData = $proker_settahunan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($program->id); ?>"><?php echo e($programs->program_kerja); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>
                    <optgroup label="Program Bulanan">
                      <?php $__currentLoopData = $proker_bulanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($program->id); ?>"><?php echo e($programs->program_kerja); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </optgroup>

                  </select>
                </div>
              </div><!-- col-6 -->
              <div class="col-lg-10">
                <div class="form-group">
                  <label class="form-control-label">Program Kerja <span class="tx-danger">*</span></label>
                  <textarea required name="proker" class="form-control" type="text"><?php echo e($program->program_kerja); ?></textarea>
                </div>
              </div><!-- col-9 -->
              <div class="col-lg-2">
                <div class="form-group">
                  <label class="form-control-label">Bobot <span class="tx-danger">*</span></label>
                  <input required name="bobot" class="form-control" type="number" max="100" min="1" value="1">
                </div>
              </div><!-- col-9 -->
              <div class="col-lg-6">
                <div class="form-group">
                    <label for="from" class="form-control-label">Tanggal Mulai <span class="tx-danger">*</span></label><br>
                    <input required name="from" class="form-control" type="date" data-date="" data-date-format="yyyy-mm-dd" value="<?php echo e($program->mulai); ?>">
                </div>
              </div><!-- col-6 -->
              <div class="col-lg-6">
                <div class="form-group">
                    <label for="to" class="form-control-label">Tanggal Berakhir <span class="tx-danger">*</span></label><br>
                    <input required name="to" class="form-control" type="date" data-date="" data-date-format="yyyy-mm-dd" value="<?php echo e($program->berakhir); ?>">
                </div>
              </div><!-- col-6 -->
            </div><!-- row -->
            <div class="form-layout-footer">
              <div class="justifier" style="text-align:right;">
              <button type="submit" class="btn btn-outline-success">Ubah</button>
              </div>
              </form>
            </div><!-- form-layout-footer -->
          </div><!-- form-layout -->
        </div> <!-- Wrapeer -->
      </div> <!-- container -->
</div>
<!-- Coding stops here  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ubah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>