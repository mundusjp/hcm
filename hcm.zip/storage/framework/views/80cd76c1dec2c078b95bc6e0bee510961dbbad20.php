<?php /* C:\xampp\htdocs\hcm\resources\views/adminparts/footer.blade.php */ ?>
<footer class="site-footer">
  <div class="footer-inner bg-white">
      <div class="row">
          <div class="col-sm-6">
              Copyright 2019 &copy; All Rights Reserved. PT Indonesia Kendaraan Terminal
          </div>
          <div class="col-sm-6 text-right">
              Designed by: <a href="">Human Capital Management Team</a></a>
          </div>
      </div>
  </div>
</footer>            
