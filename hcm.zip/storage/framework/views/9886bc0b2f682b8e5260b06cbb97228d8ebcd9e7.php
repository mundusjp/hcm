<?php /* C:\xampp\htdocs\hcm\resources\views/layouts/admin.blade.php */ ?>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <?php echo $__env->make('adminparts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

  <?php echo $__env->make('adminparts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div id="right-panel" class="right-panel">
  <?php echo $__env->make('adminparts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('content'); ?>
  <div class="clearfix"></div>
  <?php echo $__env->make('adminparts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('adminparts.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
