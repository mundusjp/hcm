<?php /* C:\xampp\htdocs\hcm\resources\views/pages/user/edit.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- coding starts here  -->
<div class="slim-mainpanel">
     <div class="container">
       <div class="slim-pageheader">
         <ol class="breadcrumb slim-breadcrumb">
           <li class="breadcrumb-item"><a href="#">Home</a></li>
           <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
         </ol>
         <h6 class="slim-pagetitle">Dashboard</h6>
       </div><!-- slim-pageheader -->
       <div class="section-wrapper mg-t-20">
         <?php if(session('success')): ?>
         <div class="alert alert-success" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong> <?php echo e(session('success')); ?> </strong>
         </div><!-- alert -->
         <?php elseif(session('failed')): ?>
         <div class="alert alert-danger" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong> <?php echo e(session('failed')); ?> </strong>
         </div><!-- alert -->
         <?php endif; ?>
         <label class="section-title">User List</label>
         <p class="mg-b-20 mg-sm-b-40">Berikut adalah list user beserta tugas-tugasnya</p>
         <form method="post" action="<?php echo e(route('users.update', $user_detail->id)); ?>">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="nama">Nama:</label>
          <input type="text" class="form-control" name="nama" value="<?php echo e($user_detail->nama); ?>" />
        </div>
        <div class="form-group">
          <label for="email">E-mail :</label>
          <input type="text" class="form-control" name="email" value="<?php echo e($user_detail->email); ?>" />
        </div>
        <div class="form-group">
          <label for="quantity">Password</label>
          <input type="password" class="form-control" name="password" value="<?php echo e($user_detail->password); ?>" />
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
      </form>
       </div>
     </div>
</div>
<!-- coding endss here  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ubah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>