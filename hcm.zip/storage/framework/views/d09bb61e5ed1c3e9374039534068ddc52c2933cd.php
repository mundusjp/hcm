<?php /* C:\xampp\htdocs\hcm\resources\views/parts/head.blade.php */ ?>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- Meta -->
<meta name="description" content="Goalsetting PT Indonesia Kendaraan Terminal.">
<meta name="author" content="Human Capital Team">

<title>Goalsetting PT Indonesia Kendaraan Terminal</title>

<!-- vendor css -->
<link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(asset('lib/Ionicons/css/ionicons.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(asset('https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css')); ?>" rel="stylesheet" type="text/css" >
<link href="<?php echo e(asset('lib/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css">
<!-- Slim CSS -->
<link href="<?php echo e(asset('css/slim.css')); ?>" rel="stylesheet" type="text/css" >
