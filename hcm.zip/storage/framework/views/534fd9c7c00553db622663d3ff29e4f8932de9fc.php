<?php /* C:\xampp\htdocs\hcm\resources\views/pages/goalsetting/ubah/direksi.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Start Coding here -->
<div class="slim-mainpanel">
      <div class="container">
        <div class="slim-pageheader">
          <h6 class="slim-pagetitle">Ubah Program Kerja Direksi</h6>
        </div><!-- slim-pageheader -->
        <div class="section-wrapper">
          <form action="<?php echo e(route('direksi.update',$program->id)); ?>" method="post">
          <?php echo method_field('PATCH'); ?>
          <?php echo e(csrf_field()); ?>

          <div class="form-layout">
            <div class="row mg-b-25">
              <div class="col-lg-6">
                <div class="form-group">
                  <label class="form-control-label">Nama: <span class="tx-danger">*</span></label>
                  <input class="form-control" type="text" name="nama" readonly value="<?php echo e(Auth::user()->nama); ?>" >
                  <input style="display:none;"class="form-control" type="text" name="id" readonly value="<?php echo e($program->id); ?>" >
                </div>
              </div><!-- col-6 -->
              <div class="col-lg-3">
                <div class="form-group">
                  <label class="form-control-label">Sub-Divisi: <span class="tx-danger">*</span></label>
                  <input class="form-control" type="text" readonly name="divisi" value="<?php echo e($program->divisi); ?>">
                </div>
              </div><!-- col-3 -->
              <div class="col-lg-3">
                <div class="form-group">
                  <label class="form-control-label">NIPP: <span class="tx-danger">*</span></label>
                  <input class="form-control" type="text" readonly name="nipp" value="<?php echo e($program->nipp); ?>">
                </div>
              </div><!-- col-3 -->
              <div class="col-lg-12">
                <div class="form-group">
                  <label class="form-control-label">Program Kerja <span class="tx-danger">*</span></label>
                  <textarea required name="proker" class="form-control" type="text"><?php echo e($program->program_kerja); ?></textarea>
                </div>
              </div><!-- col-3 -->
              <div class="col-lg-6">
                <div class="form-group">
                    <label for="from" class="form-control-label">Tanggal Mulai <span class="tx-danger">*</span></label><br>
                    <input required name="from" class="form-control" type="date" data-date="" data-date-format="yyyy-mm-dd" value="<?php echo e($program->mulai); ?>">
                </div>
              </div><!-- col-6 -->
              <div class="col-lg-6">
                <div class="form-group">
                    <label for="to" class="form-control-label">Tanggal Berakhir <span class="tx-danger">*</span></label><br>
                    <input required name="to" class="form-control" type="date" data-date="" data-date-format="yyyy-mm-dd" value="<?php echo e($program->berakhir); ?>">
                </div>
              </div><!-- col-6 -->
            </div><!-- row -->
            <div class="form-layout-footer">
              <div class="justifier" style="text-align:right;">
              <button type="submit" class="btn btn-outline-success">Ubah</button>
              </div>
              </form>
            </div><!-- form-layout-footer -->
          </div><!-- form-layout -->

        </div> <!-- Wrapeer -->
      </div> <!-- container -->
</div>
<!-- Coding stops here  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ubah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>