<?php /* C:\xampp\htdocs\hcm\resources\views/parts/header.blade.php */ ?>
<div class="slim-header">
  <div class="container">
    <div class="slim-header-left">
      <h2 class="slim-logo"><img src="<?php echo e(asset('/img/ikt-logo.png')); ?>" href="http://indonesiacarterminal.co.id"></img></h2>

      <!-- <div class="search-box">
        <input type="text" class="form-control" placeholder="Search">
        <button class="btn btn-primary"><i class="fa fa-search"></i></button>
      </div> -->
    </div><!-- slim-header-left -->
    <div class="slim-header-right">
      <div class="dropdown dropdown-c">
        <a href="#" class="logged-user" data-toggle="dropdown">
          <img src="<?php echo e(Auth::user()->avatar); ?>" alt="">
          <span><?php echo e(Auth::user()->nama); ?></span>
          <i class="fa fa-angle-down"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right">
          <nav class="nav">
            <form id="profil" action="<?php echo e(route('profile',Auth::user()->id)); ?>" method="get">
              <?php echo csrf_field(); ?>
              <a href="javascript:;" onclick="document.getElementById('profil').submit();" class="nav-link"><i class="icon ion-ios-gear"></i> Profil</a>
            </form>
            <form id="logout" action="<?php echo e(route('logout')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <a href="javascript:;" onclick="document.getElementById('logout').submit();" class="nav-link"><i class="icon ion-forward"></i> Sign Out</a>
            </form>
          </nav>
        </div><!-- dropdown-menu -->
      </div><!-- dropdown -->
    </div><!-- header-right -->
  </div><!-- container -->
</div><!-- slim-header -->
