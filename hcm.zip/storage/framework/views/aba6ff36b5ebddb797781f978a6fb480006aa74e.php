<?php /* C:\xampp\htdocs\hcm\resources\views/pages/goalsetting/supervisor.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- coding starts here  -->
    <div class="slim-mainpanel">
          <div class="container">
            <div class="slim-pageheader">
              <ol class="breadcrumb slim-breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Goal Setting</a></li>
                <li class="breadcrumb-item active" aria-current="page">Program DVP</li>
              </ol>
              <h6 class="slim-pagetitle">Program Deputy Vice Director of <?php echo e(Auth::user()->sub_subdivisi); ?></h6>
            </div><!-- slim-pageheader -->
            <div class="section-wrapper">
              <?php if(session('success')): ?>
              <div class="alert alert-success" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <strong> <?php echo e(session('success')); ?> </strong>
              </div><!-- alert -->
              <?php elseif(session('failed')): ?>
              <div class="alert alert-danger" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <strong> <?php echo e(session('failed')); ?> </strong>
              </div><!-- alert -->
              <?php endif; ?>
              <!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
              <!--                                            VicePresident                                                    -->
              <!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
              <?php if($kelas_jabatan <= 8 && $kelas_jabatan >= 6): ?>
              <?php $__currentLoopData = $semua_dpv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <label class="section-title">Program Deputy Vice President of <?php echo e($user->sub_subdivisi); ?></label>
              <table class="table table-orange">
                <thead>
                <tr>
                  <th style="width:30px">No</th>
                  <th style="width:500px">Program Kerja</th>
                  <th style="width:50px">Deadline</th>
                  <th style="width:150px">Progres</th>
                  <th style="width:150px">Status</th>
                </tr>
                </thead>
                <tbody>
                  <?php $i=0;
                  $proker_dvp = App\Task::where('nipp',$user->nipp)->get();
                  ?>
                  <?php $__currentLoopData = $proker_dvp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++;?>
                  <tr>
                  <th scope="row"><?php echo e($i); ?></th>
                  <td style="width:500px"><?php echo e($program->program_kerja); ?></td>
                  <td><?php echo e($program->due_date); ?></td>
                  <td >
                    <div class="progress mg-b-5">
                      <div class="progress-bar progress-bar-lg bg-warning wd-<?php echo e($program->progres); ?>p" role="progressbar" aria-valuenow="<?php echo e($program->progres); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e($program->progres); ?>%</div>
                    </div>
                  </td>
                  <?php if($program->status_task == "Belum Direspon" || $program->status_task == "Belum Disampaikan"): ?>
                  <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-dark"><?php echo e($program->status_task); ?></span></td>
                  <?php elseif($program->status_task == "Sedang Diproses"): ?>
                  <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-info"><?php echo e($program->status_task); ?></span></td>
                  <?php elseif($program->status_task == "Terlambat" || $program->status_task == "Diperingatkan" || $program->status_task == "Ditunda" || $program->status_task == "Konfirmasi Dibatalkan"): ?>
                  <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-warning"><?php echo e($program->status_task); ?></span></td>
                  <?php elseif($program->status_task == "Dibatalkan"): ?>
                  <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-danger"><?php echo e($program->status_task); ?></span></td>
                  <?php else: ?>
                  <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-success"><?php echo e($program->status_task); ?></span></td>
                  <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
              <br>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <hr>
              <!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
              <!--                                            Kelas DVP                                                        -->
              <!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
              <?php elseif(($kelas_jabatan >= 9 && $kelas_jabatan <=10) ||($jabatan == "Superadmin")): ?>
              <?php if(empty($program_vp[0])): ?>
              <div class="alert alert-danger" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <strong> Tidak ada tugas dari Vice President yang sedang diproses. Silahkan kembali ke dashboard dan tekan tombol Proses </strong>
              </div><!-- alert -->
              <button disabled type="button"class="btn float-right" data-toggle="modal" data-target="#tambahdvp">Tambahkan </button>
              <?php else: ?>
              <button type="button"class="btn float-right" data-toggle="modal" data-target="#tambahdvp">Tambahkan </button>
              <?php endif; ?>
              <label class="section-title">Program Kerja Anda Sebagai <?php echo e($jabatan); ?> <?php echo e($divisi); ?></label>
              <table class="table table-orange">
                <thead>
                <tr>
                  <th style="width:30px">No</th>
                  <th style="width:500px">Program Kerja</th>
                  <th style="width:50px">Deadline</th>
                  <th style="width:150px">Progres</th>
                  <th style="width:150px">Status</th>
                  <th>Ubah</th>
                  <th>Hapus</th>
                </tr>
                </thead>
                <tbody>
                  <?php $i=0;?>
                  <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++;?>
                  <tr>
                    <th scope="row"><?php echo e($i); ?></th>
                    <td style="width:500px"><?php echo e($program->program_kerja); ?></td>
                    <td><?php echo e($program->due_date); ?></td>
                    <td >
                      <div class="progress mg-b-5">
                        <div class="progress-bar progress-bar-lg bg-warning wd-<?php echo e($program->progres); ?>p" role="progressbar" aria-valuenow="<?php echo e($program->progres); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e($program->progres); ?>%</div>
                      </div>
                    </td>
                    <?php if($program->status_task == "Belum Direspon" || $program->status_task == "Belum Disampaikan"): ?>
                    <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-dark"><?php echo e($program->status_task); ?></span></td>
                    <?php elseif($program->status_task == "Sedang Diproses"): ?>
                    <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-info"><?php echo e($program->status_task); ?></span></td>
                    <?php elseif($program->status_task == "Terlambat" || $program->status_task == "Diperingatkan" || $program->status_task == "Ditunda" || $program->status_task == "Konfirmasi Dibatalkan"): ?>
                    <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-warning"><?php echo e($program->status_task); ?></span></td>
                    <?php elseif($program->status_task == "Dibatalkan"): ?>
                    <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-danger"><?php echo e($program->status_task); ?></span></td>
                    <?php else: ?>
                    <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-success"><?php echo e($program->status_task); ?></span></td>
                    <?php endif; ?>
                  <td>
                    <form id="edit" action="<?php echo e(route('deputy-vice-president.edit',$program->id)); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-outline-success" type="submit">Ubah</button>
                    </form>
                  </td>
                  <td>
                    <form id="hapus" action="<?php echo e(route('deputy-vice-president.destroy',$program->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-outline-danger" type="submit">Hapus</button>
                  </td>
                  </form>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
              <!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
              <!--                                      Kelas Officer & TNO                                                    -->
              <!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
              <?php else: ?>
                <label class="section-title">Program Kerja Deputy Vice Director <?php echo e(Auth::user()->sub_subdivisi); ?></label>
                <table class="table table-orange">
                  <thead>
                  <tr>
                    <th style="width:30px">No</th>
                    <th style="width:500px">Program Kerja</th>
                    <th style="width:50px">Deadline</th>
                    <th style="width:150px">Progres</th>
                    <th style="width:150px">Status</th>
                  </tr>
                  </thead>
                  <tbody>
                    <?php $i=0;
                    $proker_dvp = App\Task::where('nipp_pj',Auth::user()->nipp)->get();
                    ?>
                    <?php $__currentLoopData = $proker_dvp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $i++;?>
                    <tr>
                    <th scope="row"><?php echo e($i); ?></th>
                    <td style="width:500px"><?php echo e($program->program_kerja); ?></td>
                    <td><?php echo e($program->due_date); ?></td>
                    <td >
                      <div class="progress mg-b-5">
                        <div class="progress-bar progress-bar-lg bg-warning wd-<?php echo e($program->progres); ?>p" role="progressbar" aria-valuenow="<?php echo e($program->progres); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e($program->progres); ?>%</div>
                      </div>
                    </td>
                    <?php if($program->status_task == "Belum Direspon" || $program->status_task == "Belum Disampaikan"): ?>
                    <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-dark"><?php echo e($program->status_task); ?></span></td>
                    <?php elseif($program->status_task == "Sedang Diproses"): ?>
                    <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-info"><?php echo e($program->status_task); ?></span></td>
                    <?php elseif($program->status_task == "Terlambat" || $program->status_task == "Diperingatkan" || $program->status_task == "Ditunda" || $program->status_task == "Konfirmasi Dibatalkan"): ?>
                    <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-warning"><?php echo e($program->status_task); ?></span></td>
                    <?php elseif($program->status_task == "Dibatalkan"): ?>
                    <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-danger"><?php echo e($program->status_task); ?></span></td>
                    <?php else: ?>
                    <td style="width:25px;text-align:center;"><span class="badge badge-pill badge-success"><?php echo e($program->status_task); ?></span></td>
                    <?php endif; ?>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              <?php endif; ?>
              <!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
              <!--                                             MODALS                                                          -->
              <!-- /////////////////////////////////////////////////////////////////////////////////////////////////////////// -->
              <div class="modal fade" id="tambahdvp" tabindex="-1" role="dialog" aria-labelledby="ConfigUpdateLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <div class="form-layout">
                        <div class="form-group">
                          <div class="row">
                            <div class="col-12">
                              <form action="<?php echo e(route('deputy-vice-president.store')); ?>" method="post">
                              <?php echo e(csrf_field()); ?>

                              <label class="section-title">Tambahkan Program Kerja Direktur <?php echo e($divisi); ?></label>
                              <p class="mg-b-20 mg-sm-b-40">Untuk tahun <?php echo e(date('Y')); ?></p>
                              <div class="form-layout">
                                <div class="row mg-b-25">
                                  <div class="col-lg-6">
                                    <div class="form-group">
                                      <label class="form-control-label">Nama: <span class="tx-danger">*</span></label>
                                      <input class="form-control" type="text" name="nama" readonly value="<?php echo e(Auth::user()->nama); ?>" >
                                    </div>
                                  </div><!-- col-6 -->
                                  <div class="col-lg-3">
                                    <div class="form-group">
                                      <label class="form-control-label">Sub-Subdivisi: <span class="tx-danger">*</span></label>
                                      <input class="form-control" type="text" readonly name="divisi" value="<?php echo e(Auth::user()->sub_subdivisi); ?>">
                                    </div>
                                  </div><!-- col-3 -->
                                  <div class="col-lg-3">
                                    <div class="form-group">
                                      <label class="form-control-label">NIPP: <span class="tx-danger">*</span></label>
                                      <input class="form-control" type="text" readonly name="nipp" value="<?php echo e(Auth::user()->nipp); ?>">
                                    </div>
                                  </div><!-- col-3 -->
                                  <div class="col-lg-12">
                                    <div class="form-group">
                                      <label class="form-control-label">Program VP Terkait <span class="tx-danger">*</span></label>
                                      <select name="program_vp" class="form-control select2-show-search" data-placeholder="Choose one">
                                        <?php $__currentLoopData = $program_vp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($program->id); ?>"><?php echo e($program->program_kerja); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      </select>
                                    </div>
                                  </div><!-- col-12 -->
                                  <div class="col-lg-10">
                                    <div class="form-group">
                                      <label class="form-control-label">Program Kerja <span class="tx-danger">*</span></label>
                                      <textarea required name="proker" class="form-control" type="text"></textarea>
                                    </div>
                                  </div><!-- col-9 -->
                                  <div class="col-lg-2">
                                    <div class="form-group">
                                      <label class="form-control-label">Bobot <span class="tx-danger">*</span></label>
                                      <input required name="bobot" class="form-control" type="number" min="1" max="100" value="100">
                                    </div>
                                  </div><!-- col-9 -->
                                  <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="from" class="form-control-label">Tanggal Mulai <span class="tx-danger">*</span></label><br>
                                        <input required name="from" class="form-control" type="date" data-date="" data-date-format="yyyy-mm-dd" value="<?php echo e($now->format('Y-m-d')); ?>">
                                    </div>
                                  </div><!-- col-6 -->
                                  <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="to" class="form-control-label">Tanggal Berakhir <span class="tx-danger">*</span></label><br>
                                        <input required name="to" class="form-control" type="date" data-date="" data-date-format="yyyy-mm-dd" value="<?php echo e(Carbon\Carbon::tomorrow()->format('Y-m-d')); ?>">
                                    </div>
                                  </div><!-- col-6 -->
                                </div><!-- row -->
                              </div><!-- form-layout -->
                            </div> <!-- col-12 -->
                        </div>
                      </div>
                    </div>
                  </div>
                    <div class="modal-footer" style="text-align:right;">
                      <button type="submit" class="btn btn-primary bd-0">Tambahkan</button>
                      <button type="button" class="btn btn-secondary" class="close" data-dismiss="modal">Cancel</button>
                      <!-- <button type="submit" class="btn btn-primary">Update</button> -->
                    </div>
                  </form>
                </div>
              </div><!-- modal-dialog -->
            </div><!-- modal -->
            </div><!-- section-wrapper -->
          </div>
        </div>


<!-- coding endss here  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>