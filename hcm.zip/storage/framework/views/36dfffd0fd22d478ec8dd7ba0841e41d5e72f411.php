<?php /* C:\xampp\htdocs\hcm\resources\views/pages/goalmatching/goalmatching.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- coding starts here  -->
<div class="slim-mainpanel">
     <div class="container">
       <div class="slim-pageheader">
         <ol class="breadcrumb slim-breadcrumb">
           <li class="breadcrumb-item"><a href="#">Home</a></li>
           <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
         </ol>
         <h6 class="slim-pagetitle">Dashboard</h6>
       </div><!-- slim-pageheader -->
       <div class="section-wrapper mg-t-20">
         <?php if(session('success')): ?>
         <div class="alert alert-success" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong> <?php echo e(session('success')); ?> </strong>
         </div><!-- alert -->
         <?php elseif(session('failed')): ?>
         <div class="alert alert-danger" role="alert">
           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
             <span aria-hidden="true">&times;</span>
           </button>
           <strong> <?php echo e(session('failed')); ?> </strong>
         </div><!-- alert -->
         <?php endif; ?>
         <label class="section-title">Officer Anda</label>
         <div class="form-group mg-b-10-force">
           <label class="form-control-label">List Officer Anda:</label>
           <select class="form-control select" name="media_source">
             <?php $__currentLoopData = $officer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php
               $officer = $row->nama;
               echo "<option  value=\"{$officer}\">{$officer}</option>";
              ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
         </div>
    </div><!-- section-wrapper -->
  </div><!-- Container -->
</div><!--slim-mainpanel-->

<!-- coding endss here  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>