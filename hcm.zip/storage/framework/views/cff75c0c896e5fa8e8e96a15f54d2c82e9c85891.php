<?php /* C:\xampp\htdocs\hcm\resources\views/logbook_harian.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- vendor css -->
    <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" type="text/css" >
    <link href="<?php echo e(asset('lib/Ionicons/css/ionicons.css')); ?>" rel="stylesheet" type="text/css" >
    <link href="<?php echo e(asset('lib/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css">
    <!-- Slim CSS -->
    <link href="<?php echo e(asset('css/slim.css')); ?>" rel="stylesheet" type="text/css" >
  </head>
  <body>
    <div class="slim-mainpanel">
      <div class="container">
        <div class="card card-invoice">
          <div class="card-body">
            <div class="invoice-header">
              <h1 class="invoice-title">Logbook Harian</h1>
              <div class="billed-from">
                <h6><?php echo e($company->nama); ?></h6>
                <p><?php echo e($company->alamat); ?><br>
                Tel No: <?php echo e($company->no_telp); ?><br>
                Email: <?php echo e($company->email); ?></p>
              </div><!-- billed-from -->
            </div><!-- invoice-header -->

            <div class="row mg-t-20">
              <div class="col-md">
                <label class="section-label-sm tx-gray-500">Harian Milik:</label>
                <div class="billed-to">
                  <h6 class="tx-gray-800"><?php echo e(Auth::user()->nama); ?></h6>
                  <p><?php echo e(Auth::user()->jabatan); ?> <br>
                  Email: <?php echo e(Auth::user()->email); ?></p>
                </div>
              </div><!-- col -->
              <div class="col-md">
                <label class="section-label-sm tx-gray-500">Berikut adalah detail logbook harian:</label>
                <p class="invoice-info-row">
                  <span>Tanggal</span>
                  <span><?php echo e(Carbon\Carbon::now()->format('Y-m-d')); ?></span>
                </p>
              </div><!-- col -->
            </div><!-- row -->
            <div class="table-responsive mg-t-40">
              <table class="table table-invoice">
                <thead>
                  <tr>
                    <th>No.</th>
                    <th class="wd-250p">Program Kerja Terkait</th>
                    <th>Target</th>
                    <th class="wd-250p">Log Hari Ini</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $i=0;?>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $i++;?>
                  <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($log->program_kerja_terkait); ?></td>
                    <td><?php echo e($log->target); ?></td>
                    <td><?php echo e($log->logbook); ?></td>
                    <td><?php echo e($log->status); ?></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div><!-- table-responsive -->
          </div><!-- card-body -->
        </div><!-- card -->
      </div><!-- container -->
    </div><!-- slim-mainpanel -->
  </body>
</html>
